from flask import Flask, render_template, request, jsonify
import requests
from groq import Groq
from datetime import datetime, timedelta
import logging
import re

app = Flask(__name__)

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# API Configuration
NEWS_API_KEY = "86a26bef70d94117b5b3b352337d6478"
GROQ_API_KEY = "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"

# Initialize Groq client
try:
    groq_client = Groq(api_key=GROQ_API_KEY)
except Exception as e:
    logger.error(f"Groq client initialization failed: {e}")
    groq_client = None

# Enhanced spelling corrections and topic mapping
TOPIC_HANDLERS = {
    # Spelling corrections
    r'ecnomy': 'economy',
    r'analyist': 'analyst',
    r'scandel': 'scandal',

    # Topic mappings
    r'data analyist scop': 'data science career',
    r'data science scope': 'data science career prospects',
    r'world bank': 'world bank news',
    r'israel and (gaza|iran) war': 'israel conflict',
    r'pakistan and india war': 'india pakistan relations',
    r'cold play': 'coldplay',
    r'petrol price': 'oil prices',
    r'gold price': 'gold market',
    r'gaza': 'gaza conflict',
    r'ai in world': 'artificial intelligence trends'
}


def map_query_to_topic(query):
    """Map user query to known topics with spelling correction"""
    original_query = query.lower()
    for pattern, replacement in TOPIC_HANDLERS.items():
        if re.search(pattern, original_query, re.IGNORECASE):
            query = re.sub(pattern, replacement, original_query, flags=re.IGNORECASE)
            break
    return query.strip()


def get_general_knowledge(query, original_query=None):
    """Provide comprehensive information based on topic"""
    prompt = f"""
    The user asked about: "{original_query or query}" ({query}).

    Please provide:
    1. A 3-5 sentence explanation of the topic
    2. Current status/trends if applicable
    3. Suggestions for related terms to find news
    4. Keep it factual and neutral
    """

    try:
        response = groq_client.chat.completions.create(
            messages=[{"role": "user", "content": prompt}],
            model="mixtral-8x7b-32768",
            temperature=0.3,
            max_tokens=400
        )
        return response.choices[0].message.content
    except Exception as e:
        logger.error(f"General knowledge error: {e}")
        return f"I couldn't find recent news about '{original_query or query}'. Try more specific terms."


def get_news_summary(query, original_query=None):
    """Get news with intelligent fallback"""
    try:
        # First try exact match
        url = f"https://newsapi.org/v2/everything?q={query}&apiKey={NEWS_API_KEY}&pageSize=3&sortBy=relevancy"
        response = requests.get(url, timeout=10)
        data = response.json()

        if data['status'] == 'ok' and data['totalResults'] > 0:
            articles = data['articles'][:3]
            sources = [{
                'title': art['title'],
                'url': art['url'],
                'source': art['source']['name']
            } for art in articles if all(k in art for k in ['title', 'url', 'source'])]

            if sources:
                summary = "Recent updates:\n" + "\n".join(
                    f"- {art['title']}" for art in articles[:3]
                )
                return summary, sources

        # If no results, try broader search
        broader_query = query.split()[0]  # Use first word only
        if broader_query != query:
            return get_news_summary(broader_query, original_query or query)

        return None, None

    except Exception as e:
        logger.error(f"News fetch error: {e}")
        return None, None


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/ask", methods=["POST"])
def ask():
    user_query = request.form.get("query", "").strip()
    if not user_query:
        return jsonify({"response": "Please enter a search query."})

    logger.info(f"Original query: {user_query}")

    # Map query to known topics
    mapped_query = map_query_to_topic(user_query)
    was_corrected = mapped_query.lower() != user_query.lower()

    # Try to get news first
    news_summary, sources = get_news_summary(mapped_query, user_query)

    response = ""
    if was_corrected:
        response += f"Showing information about '{mapped_query}':\n\n"

    if news_summary:
        response += news_summary
    else:
        # Provide comprehensive knowledge response
        response += get_general_knowledge(mapped_query, user_query)
        response += "\n\nTry these related terms for news: " + ", ".join(
            [mapped_query] + mapped_query.split()[:2]
        )

    return jsonify({
        "response": response,
        "sources": sources or [],
        "corrected_query": mapped_query if was_corrected else None
    })


if __name__ == "__main__":
    app.run(debug=True)